"""Analysis config API routes."""

from __future__ import annotations

from fastapi import Depends, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import Any, Dict, Optional

from app.db import get_db
from app.service.config_service import get_config_service

from . import router


class ConfigSaveRequest(BaseModel):
    project_id: str
    config: Dict[str, Any]


@router.get("/config")
async def get_config(project_id: str = Query(...), db: Session = Depends(get_db)):
    return get_config_service().get_config(db, project_id)


@router.put("/config")
async def save_config(body: ConfigSaveRequest, db: Session = Depends(get_db)):
    return get_config_service().save_config(db, body.project_id, body.config)
