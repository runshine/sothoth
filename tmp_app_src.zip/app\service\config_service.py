"""Per-project analysis config service."""

from __future__ import annotations

from typing import Any, Dict

from sqlalchemy.orm import Session

from app.db.models import AppSaProjectConfig

_DEFAULT_CONFIG: Dict[str, Any] = {
    "analyse_targets": ["binary", "script", "config"],
    "binary_arch": ["all"],
    "parallel_modules": 2,
    "parallel_sub_workers": 1,
    "agent_max_retries": 100,
    "agent_retry_delay": 30,
    "pi_max_retries": -1,
    "pi_retry_delay": 10,
    "stages": {
        "classify":    {"min_rounds": 1, "max_rounds": -1, "pass_mode": "all"},
        "refine":      {"min_rounds": 1, "max_rounds": -1, "pass_mode": "all"},
        "analyse":     {"min_rounds": 1, "max_rounds": -1, "pass_mode": "all"},
        "final_check": {"min_rounds": 1, "max_rounds": -1, "pass_mode": "all"},
    },
    "workers": {
        "default_tools": ["read", "bash", "edit", "write", "grep", "find"],
        "system_prompt_dir": "/app/prompts/workers",
        "default_thinking_level": "off",
        "agents": [],
        "stage_models": {},
    },
    "judges": {
        "default_tools": ["read", "bash", "grep", "find"],
        "system_prompt_dir": "/app/prompts/judges",
        "default_thinking_level": "off",
        "agents": [],
        "stage_models": {},
    },
    "output_dir": "/data/output",
    "archive_dir": "/data/output",
    "result_dir": "/data/output",
    "start_stage": 1,
    "resume_workspace": "",
}


class ConfigService:
    def get_config(self, db: Session, project_id: str) -> dict:
        row = db.query(AppSaProjectConfig).filter_by(project_id=project_id).first()
        if row and row.config_json:
            data = {**_DEFAULT_CONFIG, **row.config_json, "project_id": project_id}
        else:
            data = {**_DEFAULT_CONFIG, "project_id": project_id}
        if row:
            data["updated_at"] = row.updated_at.isoformat() if row.updated_at else None
        return data

    def save_config(self, db: Session, project_id: str, config_data: dict) -> dict:
        # Strip project_id from the blob itself
        blob = {k: v for k, v in config_data.items() if k not in ("project_id", "updated_at")}
        row = db.query(AppSaProjectConfig).filter_by(project_id=project_id).first()
        if row:
            row.config_json = blob
        else:
            row = AppSaProjectConfig(project_id=project_id, config_json=blob)
            db.add(row)
        db.commit()
        db.refresh(row)
        result = {**blob, "project_id": project_id}
        if row.updated_at:
            result["updated_at"] = row.updated_at.isoformat()
        return result


_config_service: ConfigService | None = None


def get_config_service() -> ConfigService:
    global _config_service
    if _config_service is None:
        _config_service = ConfigService()
    return _config_service
