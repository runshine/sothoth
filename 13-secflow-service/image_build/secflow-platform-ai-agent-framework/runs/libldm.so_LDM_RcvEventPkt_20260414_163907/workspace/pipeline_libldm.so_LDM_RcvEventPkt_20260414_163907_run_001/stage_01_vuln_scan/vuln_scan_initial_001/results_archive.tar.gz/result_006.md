# 漏洞报告: LDM_DispatchByProtype中未检查指针算术导致越界写入

## 精确位置
- **函数名**: LDM_DispatchByProtype
- **源文件**: /home/qinghe/ai-workspace/target/libldm.so.c
- **漏洞代码行**: 第368138-368140行, 第368148-368151行
- **数据流关联**: 子追踪A-2: 通过LDM_DispatchProcessByProType调用链到达

## 漏洞类型与 CWE
- CWE-119: Out-of-bounds Write (未检查的指针算术导致内存写入越界)
- CWE-125: Out-of-bounds Read (读取越界)

## 严重性与置信度
严重性: High
置信度: 高
与主函数中的漏洞模式相同，可导致攻击者控制下的任意内存读写。

## 源代码片段
```c
// libldm.so.c:368138-368151
v19 = *(_QWORD *)(a1 + 904);
v20 = *(unsigned __int16 *)(v19 + 108);
if ( (_WORD)v20 && (v12 = v19 + v20) != 0 )
{
    v14 = *(_WORD *)(v12 + 16);  // 越界读取！
}
else
{
    v22 = *(_QWORD *)(a4 + 24596);
    v14 = 0;
    v12 = v22;
    if ( v22 )
        v14 = *(_WORD *)(v12 + 16);
}
v21 = *(unsigned __int16 *)(v19 + 108);
if ( (_WORD)v21 )
{
    v13 = v19 + v21;  // 同样的未检查指针算术！
    if ( v19 + v21 )
        goto LABEL_15;
}
```

## 完整攻击路径

### 攻击入口
- **调用链**: LDM_RcvEventPkt → LDM_DispatchProcessByProType → LDM_DispatchByProtype
- **原始输入**: a1 (LDM句柄结构体指针), a4 (全局上下文指针)

### 传播路径
1. **路径1 (v12分支)**:
   - `v19 = *(_QWORD *)(a1 + 904)` - 从a1读取扩展信息指针
   - `v20 = *(unsigned __int16 *)(v19 + 108)` - 读取偏移值(16位)
   - `v12 = v19 + v20` - **无边界检查的指针算术**
   - `v14 = *(_WORD *)(v12 + 16)` - 从计算地址读取

2. **路径2 (v13分支)**:
   - `v21 = *(unsigned __int16 *)(v19 + 108)` - 再次读取偏移值
   - `v13 = v19 + v21` - **同样的未检查指针算术**
   - 后续可能写入

### 校验分析
- 条件 `(_WORD)v20` 仅检查v20非零
- 条件 `v12 != 0` 仅检查非NULL
- 完全没有验证v20是否在合理范围内

## 触发条件
1. 通过发送特制数据包触发协议分发路径
2. 控制a1+904处的指针值
3. 控制该指针+108偏移处的16位值

## 影响评估
- **影响类型**: 任意内存读取/写入
- **后果**: 可能导致RCE、DoS或信息泄露

## 关联漏洞
此漏洞与以下漏洞形成漏洞族:
- result_001.md: LDM_RcvEventPkt中相同模式
- result_002.md: LDM_RcvEventIPv6SrhTtlExceed中相同模式
- result_003.md: LDM_RcvEventPkt else分支